# Exercise Local Storage

Starting with the previous exercise, write a method that recover the data saved in `localStorage` and print them in the console

Tips:

- Remember to use the available `JSON methods` (parse, stringify)
