# Dom Tree - Exercise 3

Get the value of all `input` and `label` fields.

The output in the console must be:

```
First Name: Mario
Last Name: Rossi
Age: 25
```
