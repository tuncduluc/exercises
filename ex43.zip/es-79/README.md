# Exercise Local Storage

In the `exercise.js` file, we find a `user` object. Write a function that saves the user object in `localStorage` with its 'user' key.

Tips:

- Remember to use the available `JSON methods` (parse, stringify)
